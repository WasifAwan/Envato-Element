export const menuItems = [
    { to: '/', label: 'Home' },
    { to: '/About', label: 'Pages' },
    { to: '/Services1', label: 'Services' },
    { to: '/Project1', label: 'Projects' },
    { to: '/Bloggrid', label: 'Blog' },
];
