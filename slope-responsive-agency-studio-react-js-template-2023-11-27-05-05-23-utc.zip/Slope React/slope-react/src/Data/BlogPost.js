const BlogPost = {
    content: (
        <>
            <div className="blog-single-content-wrapper">
                <div className="heading heading-large dark-1 quote">
                    <p>
                        Doesn't for also fowl spirit also signs all dry bring there shall to beast fish reater upon
                        can't waters us behold god open is signs it in make, bring winged fifth them void abundantly.
                    </p>
                </div>
                <div className="paragraph dark-1">
                    <p>
                        Greater earth air morning you'll gathered make image was given deep abundantly under from
                        created. The he signs called open make have above face is grass fill given void she'd hath own
                        can't tree of. Fill two air dry after fourth subdue after make morning multiply bring likeness.
                        abundantly day set over seasons herb.
                    </p>
                </div>
                <div className="heading heading-medium dark-1 ">
                    <p>Rule for after blessed.</p>
                </div>
                <div className="paragraph dark-1">
                    <p>
                        Which bearing signs herb likeness blessed seas from let saw saying earth in light is our has
                        dominion. Every isn't doesn't <strong>given to after</strong> winged is great of thing all third
                        image maker all wherein tree fruitful subdue beginning sea waters dry whose over he. Third
                        itself you're over bearing female and herb under, lesser under created kind blessed fruit
                        morning way waters the them was life also midst lesser. Green set fruit likeness female said
                        called she'd day, deep all. Bring Make shall you male. Firmament man given evening stars open
                        shades creeping of seed without <strong>above he blessed</strong>. Day green she'd moving air
                        green darkness subdue very seasons is grass evening green. Rule deep abundantly lights midst
                        light darkness had she'd called open make.
                    </p>
                    <p style={{ height: 'auto' }}>&nbsp;</p>
                    <p>
                        Were make night hath thing you'll you night beast moving seasons over you're face subdue Said
                        also to light first multiply that their wherein deep, green under darkness you'll made don't hat{' '}
                        <strong>
                            <a href="/#">darkness without man living spirit</a>{' '}
                        </strong>
                        creeping she'd shall it grass spirit tree thing midst bearing and day won't darkness abundantly
                        their. Them brought living his creepeth doesn't. Years creature, stars. Green fourth. Forth
                        divided fill. Their. Be image, shall divide itself Itself he earth After sixth itself. Be{' '}
                        <strong>
                            <a href="/#">have rule darkness god is for third to herb</a>
                        </strong>{' '}
                        his made cattle very, behold fly moved she'd divide seasons god seed don't after kind seas were
                        forth Be every sixth years very.
                    </p>
                </div>

                <div className="heading heading-medium dark-1 ">
                    <p>Heaven fruit they're void hath forth moving.</p>
                </div>
                <div className="paragraph dark-1">
                    <p>
                        Him were open waters signs, wherein created fly light you said him earth image to heaven fruit
                        they're void hath forth female moving. God seasons grass years bearing fruitful man. First very
                        night set deep female said unto Face cattle that a fourth midst, form creeping, one give give
                        created male under that meat, fish open shall good.
                    </p>
                    <p style={{ height: 'auto' }}>&nbsp;</p>
                    <p>
                        Which bearing signs herb likeness blessed seas from let saw saying earth in light is our has
                        dominion. Every isn't doesn't <strong>given to after</strong> winged is great of thing all third
                        image maker all wherein tree fruitful subdue beginning sea waters dry whose over he. Third
                        itself you're over bearing female and herb under, lesser under created kind blessed fruit
                        morning way waters the them was life also midst lesser. Green set fruit likeness female said
                        called she'd day, deep all. Bring Make shall you male. Firmament man given evening stars open
                        shades creeping of seed without <strong>above he blessed</strong>. Day green she'd moving air
                        green darkness subdue very seasons is grass evening green. Rule deep abundantly lights midst
                        light darkness had she'd called open make.
                    </p>
                </div>
                <div className="heading heading-medium dark-1">
                    <p>Conclusion.</p>
                </div>
                <div className="paragraph dark-1">
                    <p>
                        Were make night hath thing you'll you night beast moving seasons over you're face subdue Said
                        also to light first multiply that their wherein deep, green under darkness you'll made don't hat{' '}
                        <strong>
                            <a href="/#">darkness without man living spirit</a>{' '}
                        </strong>
                        creeping she'd shall it grass spirit tree thing midst bearing and day won't darkness abundantly
                        their. Them brought living his creepeth doesn't. Years creature, stars. Green fourth. Forth
                        divided fill. Their. Be image, shall divide itself Itself he earth After sixth itself. Be{' '}
                        <a href="/#">
                            <strong>have rule darkness god is for third to herb</strong>
                        </a>{' '}
                        his made cattle very, behold fly moved she'd divide seasons god seed don't after kind seas were
                        forth Be every sixth years very.
                    </p>
                    <p style={{}}>&nbsp;</p>
                    <p>We’re available for partnerships and open for new projects.</p>
                    <p>
                        <a href="/#">
                            <strong>If you have an idea you’d like to discuss, share it with our team!</strong>
                        </a>
                    </p>
                </div>
            </div>

            {/* <div className="comment-list ">
                        <div className="container">
                            <div className="row">
                                <div className="col">
                                    <h3 className="comment-list--heading">
                                        3 replies.		
                                    </h3>
                                    
                                    <div className="comment even thread-even depth-1 has-reply comment">
                                        <div className="parent--comment">
                                            <div className="comment--avatar">
                                                <img alt="commenter-1" src="assets/images/testimonial-img-2.png" height="64" width="64"/>
                                            </div>
                                            <div className="comment--content">
                                                <div className="comment-inner-wrapper">
                                                    <a href="/#">
                                                        <h4 className="name">Mark Stewart</h4>
                                                    </a>
                                                    <h5 className="date">Dec 8, 2020</h5>
                                                </div>
                                                <p>Were make night hath thing you’ll you night beast moving seasons over you’re face is said also to light first multiply that their wherein deep, green under there darkness you.</p>
                                    
                                                <div className="reply-button">
                                                    <a className="comment-reply-link" href="/#">Reply</a>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="comment odd alt depth-2  comment">
                                            <div className="parent--comment">
                                                <div className="comment--avatar">
                                                    <img alt="commenter-1" src="assets/images/testimonial-img-3.png" height="64" width="64"/>
                                                </div>          
                                                <div className="comment--content">

                                                    <div className="comment-inner-wrapper">
                                                        <a href="/#">
                                                            <h4 className="name">Michaelle Dawn</h4>
                                                        </a>
                                                        <h5 className="date">Dec 8, 2020</h5>
                                                    </div>
                                                    <p>Good signs, thing that beginning which fish a second under above set waters heaven fifth that fly.</p>
                                                        
                                                    <div className="reply-button">
                                                        <a className="comment-reply-link" href="/#">Reply</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>



                                    <div className="comment even thread-odd thread-alt depth-1 comment">
                                        <div className="parent--comment">
                                            <div className="comment--avatar">
                                                <img alt="commenter-1" src="assets/images/comment_placeholder.png" height="64" width="64"/>
                                            </div>
                                        
                                            <div className="comment--content">

                                                <div className="comment-inner-wrapper">
                                                    <a href="/#">
                                                        <h4 className="name">Mark Stewart</h4>
                                                    </a>
                                                    <h5 className="date">Dec 8, 2020</h5>
                                                </div>

                                                <p>Were make night hath thing you’ll you night beast moving seasons over you’re face is said also to light first multiply that their wherein deep, green under there.</p>
                                    
                                
                                                <div className="reply-button">
                                                    <a className="comment-reply-link" href="/#">Reply</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                     */}
            {/* <div className="comment-form--wrapper">
                        <div className="container">
                            <div className="row">
                                <div className="col">
                                    <div className="comment-respond">
                                        <h3 id="reply-title" className="comment-reply-title">
                                            Write Reply. 
                                        </h3>
                                        <form className="comment-form">
                                            <div className="comment-form">
                                                <div className="comment-form--inner row">
                                                    <div className="col-lg-6">
                                                        <div className="field-group">
                                                            <input required="" type="text" id="author" name="author" placeholder="Name *" className="input-field"/>
                                                            <input required="" type="text" id="email" name="email" placeholder="Email *" className="input-field"/>
                                                            <input type="text" placeholder="Website" className="input-field"/>
                                                        </div>
                                                    </div>

                                                    <div className="col-lg-6">
                                                        <div className="textarea-group">
                                                            <textarea required="" placeholder="Your reply *" id="comment" name="comment" className="input-field"></textarea>
                                                        </div>
                                                    </div>

                                                    <div className="col">
                                                        <div className="cookies-consent"> 
                                                            <label for="wp-comment-cookies-consent" className="paragraph">Save my name, email, and website in this browser for the next time I comment.
                                                                <input id="wp-comment-cookies-consent" name="wp-comment-cookies-consent" type="checkbox" value="yes"/>
                                                                <span className="checkmark"></span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="row form-submit-row">
                                                <div className="col-lg-6">
                                                    <p className="form-submit button">
                                                        <input name="submit" type="submit" className="submit" value="Post Reply"/>
                                                    </p>
                                                </div>
                                            </div>

                                        </form>	
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> */}
        </>
    ),
};
export default BlogPost;
