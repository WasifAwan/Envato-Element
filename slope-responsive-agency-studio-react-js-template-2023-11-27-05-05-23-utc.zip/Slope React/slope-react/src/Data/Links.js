export const links = [
    {
        facebookLink: 'https://www.facebook.com/gfx.partner',
        twitterLink: 'https://twitter.com/gfxpartner',
        pinterestLink: 'https://www.pinterest.com/gfxpartner',
        behanceLink: 'https://www.behance.net/gfxpartner',
    },
];
