export const socialMediaData = [
    {
        href: 'https://www.facebook.com/gfx.partner',
        icon: 'fab fa-facebook',
    },
    {
        href: 'https://twitter.com/gfxpartner',
        icon: 'fab fa-twitter',
    },
    {
        href: 'https://www.pinterest.com/gfxpartner',
        icon: 'fab fa-pinterest',
    },
    {
        href: 'https://www.behance.net/gfxpartner',
        icon: 'fab fa-behance',
    },
];
