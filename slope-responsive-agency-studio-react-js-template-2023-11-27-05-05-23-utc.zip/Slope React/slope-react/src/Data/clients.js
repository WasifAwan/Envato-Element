import image from '../assets/images/client_logo_1.png';

const clients = [
    {
        url: '#',
        image: {
            src: image,
            alt: 'client image',
        },
    },
    {
        url: '#',
        image: {
            src: image,
            alt: 'client image',
        },
    },
    {
        url: '#',
        image: {
            src: image,
            alt: 'client image',
        },
    },
    {
        url: '#',
        image: {
            src: image,
            alt: 'client image',
        },
    },
    {
        url: '#',
        image: {
            src: image,
            alt: 'client image',
        },
    },
    {
        url: '#',
        image: {
            src: image,
            alt: 'client image',
        },
    },
];

export default clients;
