import Preloader from "@/helper/Preloader";

export default function Loading() {
    return <Preloader />
}