import blog_thumbnail_01 from '../assets/images/blog_thumbnail_small_img_1.jpg';
import blog_thumbnail_02 from '../assets/images/blog_thumbnail_small_img_2.jpg';
import blog_thumbnail_03 from '../assets/images/blog_thumbnail_small_img_3.jpg';
import blog_thumbnail_04 from '../assets/images/blog_thumbnail_small_img_4.jpg';
import blog_thumbnail_05 from '../assets/images/blog_thumbnail_small_img_5.jpg';
import blog_thumbnail_06 from '../assets/images/blog_thumbnail_small_img_6.jpg';
import blog_thumbnail_07 from '../assets/images/blog_thumbnail_small_img_7.jpg';
import blog_thumbnail_08 from '../assets/images/blog_thumbnail_small_img_8.jpg';

export const RelatedBlogs = [
    {
        image: blog_thumbnail_01,
        date: '23 Sep. 2020',
        category: 'Company',
        title: 'New developments on the way and the team couldn’t be more excited.',
        description:
            'Doesn’t for also fowl spirit also signs all dry bring there shall to beast fish reater upon can’t…',
    },

    {
        image: blog_thumbnail_02,
        date: '23 Sep. 2020',
        category: 'Design',
        title: 'Is hand held tech shaping the way we used to do business?',
        description:
            'Seasons grass years bearing fruitful man. First very night set deep female said unto Face cattle that a…',
    },

    {
        image: blog_thumbnail_03,
        date: '23 Sep. 2020',
        category: 'Development',
        title: 'Is hand held tech shaping the way we used to do business?',
        description:
            'Seasons grass years bearing fruitful man. First very night set deep female said unto Face cattle that a…',
    },

    {
        image: blog_thumbnail_04,
        date: '23 Sep. 2020',
        category: 'Technology',
        title: 'Is hand held tech shaping the way we used to do business?',
        description:
            'Seasons grass years bearing fruitful man. First very night set deep female said unto Face cattle that a…',
    },

    {
        image: blog_thumbnail_05,
        date: '23 Sep. 2020',
        category: 'Design',
        title: 'Is hand held tech shaping the way we used to do business?',
        description:
            'Seasons grass years bearing fruitful man. First very night set deep female said unto Face cattle that a…',
    },

    {
        image: blog_thumbnail_06,
        date: '23 Sep. 2020',
        category: 'Company',
        title: 'Is hand held tech shaping the way we used to do business?',
        description:
            'Seasons grass years bearing fruitful man. First very night set deep female said unto Face cattle that a…',
    },

    {
        image: blog_thumbnail_07,
        date: '23 Sep. 2020',
        category: 'Development',
        title: 'Is hand held tech shaping the way we used to do business?',
        description:
            'Seasons grass years bearing fruitful man. First very night set deep female said unto Face cattle that a…',
    },

    {
        image: blog_thumbnail_08,
        date: '23 Sep. 2020',
        category: 'Technology',
        title: 'Is hand held tech shaping the way we used to do business?',
        description:
            'Seasons grass years bearing fruitful man. First very night set deep female said unto Face cattle that a…',
    },
];
