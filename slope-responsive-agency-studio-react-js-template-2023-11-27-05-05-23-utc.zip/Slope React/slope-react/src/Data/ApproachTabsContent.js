export const ApproachTabsContent = [
    {
        name: 'Discovery',
        content: (
            <>
                <p>
                    Light above i created light hath midst signs creeping you'll upon land behold also gathered signs
                    hath has moveth darkness made abundantly grass. Make you darkness very is greater their place them
                    the it grass subdue fourth you're his open for meat midst under face multiply place sea.
                </p>
                <p style={{ height: 'auto' }}>&nbsp;</p>
                <p>
                    Bearing earth fowl is saw herb stars night won't set midst have this replenish likeness from all.
                    Together itself thing moving doesn't first third air gathering earth likeness green she'd all saw
                    their two night fill may appear it life multiply wherein saw fowl midst that kind you're his open
                    for meat them the it grass subdue waters.
                </p>
            </>
        ),
    },

    {
        name: 'Strategy',
        content: (
            <>
                <p>
                    Bearing earth fowl is saw herb stars night won't set midst have this replenish likeness from all.
                    Together itself thing moving doesn't first third air gathering earth likeness green she'd all saw
                    their two night fill may appear it life multiply wherein saw fowl midst that kind you're his open
                    for meat them the it grass subdue waters.
                </p>
                <p style={{ height: 'auto' }}>&nbsp;</p>
                <p>
                    Light above i created light hath midst signs creeping you'll upon land behold also gathered signs
                    hath has moveth darkness made abundantly grass. Make you darkness very is greater their place them
                    the it grass subdue fourth you're his open for meat midst under face multiply place sea.
                </p>
            </>
        ),
    },

    {
        name: 'Design',
        content: (
            <>
                <p>
                    Light above i created light hath midst signs creeping you'll upon land behold also gathered signs
                    hath has moveth darkness made abundantly grass. Make you darkness very is greater their place them
                    the it grass subdue fourth you're his open for meat midst under face multiply place sea.
                </p>
                <p style={{ height: 'auto' }}>&nbsp;</p>
                <p>
                    Bearing earth fowl is saw herb stars night won't set midst have this replenish likeness from all.
                    Together itself thing moving doesn't first third air gathering earth likeness green she'd all saw
                    their two night fill may appear it life multiply wherein saw fowl midst that kind you're his open
                    for meat them the it grass subdue waters.
                </p>
            </>
        ),
    },

    {
        name: 'Development',
        content: (
            <>
                <p>
                    Bearing earth fowl is saw herb stars night won't set midst have this replenish likeness from all.
                    Together itself thing moving doesn't first third air gathering earth likeness green she'd all saw
                    their two night fill may appear it life multiply wherein saw fowl midst that kind you're his open
                    for meat them the it grass subdue waters.
                </p>
                <p style={{ height: 'auto' }}>&nbsp;</p>
                <p>
                    Light above i created light hath midst signs creeping you'll upon land behold also gathered signs
                    hath has moveth darkness made abundantly grass. Make you darkness very is greater their place them
                    the it grass subdue fourth you're his open for meat midst under face multiply place sea.
                </p>
            </>
        ),
    },

    {
        name: 'Testing',
        content: (
            <>
                <p>
                    Light above i created light hath midst signs creeping you'll upon land behold also gathered signs
                    hath has moveth darkness made abundantly grass. Make you darkness very is greater their place them
                    the it grass subdue fourth you're his open for meat midst under face multiply place sea.
                </p>
                <p style={{ height: 'auto' }}>&nbsp;</p>
                <p>
                    Bearing earth fowl is saw herb stars night won't set midst have this replenish likeness from all.
                    Together itself thing moving doesn't first third air gathering earth likeness green she'd all saw
                    their two night fill may appear it life multiply wherein saw fowl midst that kind you're his open
                    for meat them the it grass subdue waters.
                </p>
            </>
        ),
    },

    {
        name: 'Product Launch',
        content: (
            <>
                <p>
                    Bearing earth fowl is saw herb stars night won't set midst have this replenish likeness from all.
                    Together itself thing moving doesn't first third air gathering earth likeness green she'd all saw
                    their two night fill may appear it life multiply wherein saw fowl midst that kind you're his open
                    for meat them the it grass subdue waters.
                </p>
                <p style={{ height: 'auto' }}>&nbsp;</p>
                <p>
                    Light above i created light hath midst signs creeping you'll upon land behold also gathered signs
                    hath has moveth darkness made abundantly grass. Make you darkness very is greater their place them
                    the it grass subdue fourth you're his open for meat midst under face multiply place sea.
                </p>
            </>
        ),
    },

    {
        name: 'Maintenance',
        content: (
            <>
                <p>
                    Light above i created light hath midst signs creeping you'll upon land behold also gathered signs
                    hath has moveth darkness made abundantly grass. Make you darkness very is greater their place them
                    the it grass subdue fourth you're his open for meat midst under face multiply place sea.
                </p>
                <p style={{ height: 'auto' }}>&nbsp;</p>
                <p>
                    Bearing earth fowl is saw herb stars night won't set midst have this replenish likeness from all.
                    Together itself thing moving doesn't first third air gathering earth likeness green she'd all saw
                    their two night fill may appear it life multiply wherein saw fowl midst that kind you're his open
                    for meat them the it grass subdue waters.
                </p>
            </>
        ),
    },
];
