export const TextContentData = [
    {
        heading: 'STRATEGIC SESSION',
        content:
            'Be heaven man be face fowl waters deep seas after seeing every she was for to behold days sixth sea said whose him fruitful forth good is very made in rule fill signs great spirit bring by beast abundantly heaven form in own seasons has saying man there said earth without set his is hath forth so image thing also blessed seas be creature of them man female their behold this third rule to give.',
    },
    {
        heading: 'FREE CONSULTATION',
        content:
            'Be heaven man be face fowl waters deep seas after seeing every she was for to behold days sixth sea said whose him fruitful forth good is very made in rule fill signs great spirit bring by beast abundantly heaven form in own seasons has saying man there said earth without set his is hath forth so image thing also blessed seas be creature of them man female their behold this third rule to give.',
    },
];
